# Frozen SOAR search-input research bundle

Research input bundle as provided by author; original four JSONL streams are bitwise unchanged and match the recorded SHA-256 values.

- playbook_source_clean_inputs.jsonl: original 1606-playbook C-track frozen clean source/encoder text
- query_source_clean_inputs.jsonl: original 30-query C-track clean source/encoder text
- anchor_50_clean_binding.jsonl: original anchor mappings (50); **NOT** the actual B0/B1 anchor encoded texts
- token_lengths.jsonl: original 1766 tokenization records
- playbook_primary_830_derived.jsonl: publication helper, deterministically filtered by PRIMARY_MACHINE_SELECTED (NOT an original frozen file)

Attribution: derived from Cortex XSOAR content, https://github.com/demisto/content, pinned upstream revision 31e7712111e5b33615a8decd82caa45f51a87346. MIT license text in third_party/demisto-content-LICENSE.txt. Verify any file-specific license notice when reusing upstream materials.

Before exposing source text publicly, check the 6 email-format strings in upstream-derived content for privacy and redistribution context. Do not sanitize original scientific input in place, as this would invalidate the frozen hashes and potentially change E5 embeddings.

The original input files are sufficient to analyze the C-primary(830) and C-broad(1606) clean source, but are **not sufficient** on their own to rerun every original track: the B1/B0 actual anchor encoder texts and production ranking references must also be obtained.

This bundle provides no trained E5 model weights. No full encoding or retrieval rerun has been executed by creating the bundle.
